
package se.skola;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 *  @author rimazivkovic  
 * 
 */
public class MyConnection {
   
     public static Connection getConnection(){
         
         Connection con = null;
         try{
            Class.forName("com.mysql.cj.jdbc.Driver");
                con = DriverManager.getConnection("jdbc:mysql://localhost/school.db?zeroDateTimeBehavior=convertToNull&serverTimezone=UTC", "root", "Rimanda81");
        }catch(ClassNotFoundException | SQLException e){
            System.out.println(e.getMessage());
        }
         
         return con;
     }

    }
