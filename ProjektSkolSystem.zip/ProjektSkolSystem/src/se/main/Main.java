
package se.main;

import se.view.StartFrame;

/**
 *
 * @author rimazivkovic
 */
public class Main {
    
    public static void main(String[] args) {
        StartFrame st = new StartFrame();
        st.setVisible(true);
    }
    
}
